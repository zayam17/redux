import  UserApi from '../data/userApi';

export default{
    users:[]
}